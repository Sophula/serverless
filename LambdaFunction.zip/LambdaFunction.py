# declare a lambda function
greet = lambda : print('Hello World')

# call lambda function
greet()

# Output: Hello World